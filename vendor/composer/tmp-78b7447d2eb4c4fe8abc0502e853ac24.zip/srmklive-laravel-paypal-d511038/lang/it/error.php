<?php

return [
    'paypal_transaction_declined'     => 'Impossibile elaborare il pagamento perché la tua transazione è stata rifiutata su PayPal',
    'paypal_transaction_not_verified' => 'Impossibile verificare la transazione su PayPal',
    'paypal_connection_error'         => 'Impossibile connettersi a PayPal. Si prega di riprovare',
];
