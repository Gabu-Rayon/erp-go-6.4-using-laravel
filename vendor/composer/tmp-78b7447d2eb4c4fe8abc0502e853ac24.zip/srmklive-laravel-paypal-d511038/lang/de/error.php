<?php

return [
    'paypal_transaction_declined'     => 'Zahlung konnte nicht verarbeitet werden, da Ihre Transaktion bei PayPal abgelehnt wurde',
    'paypal_transaction_not_verified' => 'Transaktion konnte bei PayPal nicht verifiziert werden',
    'paypal_connection_error'         => 'Verbindung zu PayPal konnte nicht hergestellt werden. Bitte versuchen Sie es erneut',
];
