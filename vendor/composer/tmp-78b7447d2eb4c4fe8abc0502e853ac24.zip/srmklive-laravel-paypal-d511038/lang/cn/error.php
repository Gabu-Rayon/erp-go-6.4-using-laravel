<?php

return [
    'paypal_transaction_declined'     => '由于您的交易在PayPal上被拒绝，无法处理付款',
    'paypal_transaction_not_verified' => '无法从PayPal验证交易',
    'paypal_connection_error'         => '无法连接到PayPal。请重试',
];
