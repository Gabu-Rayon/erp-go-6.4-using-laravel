<?php

return [
    'paypal_transaction_declined'     => 'Imposible procesar el pago ya que tu transacción fue rechazada en PayPal',
    'paypal_transaction_not_verified' => 'Imposible verificar la transacción desde PayPal',
    'paypal_connection_error'         => 'Imposible conectarse a PayPal. Por favor, inténtalo de nuevo',
];
