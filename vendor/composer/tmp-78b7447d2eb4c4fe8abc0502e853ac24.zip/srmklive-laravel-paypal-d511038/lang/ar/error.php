<?php

return [
    'paypal_transaction_declined'     => 'غير قادر على معالجة الدفعة لأن معاملتك تم رفضها على PayPal',
    'paypal_transaction_not_verified' => 'غير قادر على التحقق من المعاملة من PayPal',
    'paypal_connection_error'         => 'غير قادر على الاتصال بـ PayPal. الرجاء المحاولة مرة أخرى',
];
