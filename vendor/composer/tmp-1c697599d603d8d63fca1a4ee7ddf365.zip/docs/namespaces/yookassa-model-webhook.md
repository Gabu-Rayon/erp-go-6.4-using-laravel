# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Model\Webhook

## Parent: [\YooKassa\Model](../namespaces/yookassa-model.md)

### Interfaces

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Model\Webhook\WebhookInterface](../classes/YooKassa-Model-Webhook-WebhookInterface.md) | Interface WebhookInterface. |

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Model\Webhook\Webhook](../classes/YooKassa-Model-Webhook-Webhook.md) | Класс Webhook содержит информацию о подписке на одно событие. |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 19](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2023-12-11 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2023 YooMoney