# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Model\Settings

## Parent: [\YooKassa\Model](../namespaces/yookassa-model.md)

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Model\Settings\FiscalizationData](../classes/YooKassa-Model-Settings-FiscalizationData.md) | Класс, представляющий модель FiscalizationData. |
| [\YooKassa\Model\Settings\FiscalizationProvider](../classes/YooKassa-Model-Settings-FiscalizationProvider.md) | Класс, представляющий модель FiscalizationProvider. |
| [\YooKassa\Model\Settings\Me](../classes/YooKassa-Model-Settings-Me.md) | Класс, представляющий модель Me. |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 19](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2023-12-11 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2023 YooMoney