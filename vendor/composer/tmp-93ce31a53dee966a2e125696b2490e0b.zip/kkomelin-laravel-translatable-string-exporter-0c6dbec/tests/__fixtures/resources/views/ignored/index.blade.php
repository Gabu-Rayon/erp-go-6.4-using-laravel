{{ __('ignored string') }}
