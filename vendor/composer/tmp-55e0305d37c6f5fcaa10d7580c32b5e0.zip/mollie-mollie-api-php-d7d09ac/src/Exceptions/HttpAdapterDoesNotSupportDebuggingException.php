<?php

namespace Mollie\Api\Exceptions;

class HttpAdapterDoesNotSupportDebuggingException extends ApiException
{
}
